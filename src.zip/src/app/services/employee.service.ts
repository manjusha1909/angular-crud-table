import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class EmployeeService {
  private employees = [
    { id :1, name : 'sam', position: 'Developer', salary:5000},
    { id :2, name : 'kevin', position: 'Manager', salary: 7000}
  ];

  getEmployees(){
    return this.employees;
  }

  getEmployeeById(id: number) {
    return this.employees.find((emp)=> emp.id ===id);
  }

  addEmployee(employee: any){
    this.employees.push(employee);
  }

  updateEmployee(id: number , updatedEmployee : any){
    const index = this. employees.findIndex((emp)=> emp.id === id);
    if (index ! == -1){
      this.employees[index] = updatedEmployee;
    }
  }

  deleteEmployee(id:number){
    this.employees= this.employees.filter((emp)=>emp.id ! == id)
  }

  constructor() { }
}
