import { Component } from '@angular/core';
import { EmployeeService } from '../../../services/employee.service';

@Component({
  selector: 'app-employee-list',
  imports: [],
  templateUrl: './employee-list.component.html',
  styleUrl: './employee-list.component.css'
})
export class EmployeeListComponent {
  employees : any[] = [];

  constructor(private employeeService: EmployeeService){
    this.employees = this.employeeService.getEmployees();
  }

  deleteEmployee(id:number){
    this.employeeService.deleteEmployee(id);
    this.employees = this.employeeService.getEmployees();
  }

}
