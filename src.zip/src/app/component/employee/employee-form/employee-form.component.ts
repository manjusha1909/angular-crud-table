import { Component } from '@angular/core';
import { EmployeeService } from '../../../services/employee.service';
import { ActivatedRoute, Router } from '@angular/router';

@Component({
  selector: 'app-employee-form',
  templateUrl: './employee-form.component.html',
  styleUrls: ['./employee-form.component.css'],
})
export class EmployeeFormComponent {
  employee: any = { id: null, name: '', position: '', salary: 0 };

  constructor(
    private employeeService: EmployeeService,
    private route: ActivatedRoute,
    private router: Router
  ) {
    const id = this.route.snapshot.params['id'];
    if (id) {
      const existingEmployee = this.employeeService.getEmployeeById(+id);
      if (existingEmployee) {
        this.employee = { ...existingEmployee };
      }
    }
  }

  saveEmployee() {
    if (this.employee.id) {
      this.employeeService.updateEmployee(this.employee.id, this.employee);
    } else {
      this.employee.id = Date.now();
      this.employeeService.addEmployee(this.employee);
    }
    this.router.navigate(['/employees']);
  }
}
