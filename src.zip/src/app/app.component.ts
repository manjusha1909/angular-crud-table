import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css'],
})
export class AppComponent {
  products = [
    { id: 1, name: 'Product A', price: 100 },
    { id: 2, name: 'Product B', price: 200 },
    { id: 3, name: 'Product C', price: 300 },
  ];

  // Bar chart data
  barChartData = this.products.map(product => ({
    name: product.name,
    value: product.price,
  }));

  // Dialog and form controls
  displayDialog = false;
  newProduct = { id: 0, name: '', price: 0 };

  // Add a new product
  addProduct() {
    if (this.newProduct.id === 0) {
      this.newProduct.id = this.products.length + 1;
      this.products.push({ ...this.newProduct });
    } else {
      const index = this.products.findIndex(p => p.id === this.newProduct.id);
      this.products[index] = { ...this.newProduct };
    }
    this.updateChartData();
    this.closeDialog();
  }

  // Edit a product
  editProduct(product: any) {
    this.newProduct = { ...product };
    this.displayDialog = true;
  }

  // Delete a product
  deleteProduct(product: any) {
    this.products = this.products.filter(p => p.id !== product.id);
    this.updateChartData();
  }

  // Update chart data
  updateChartData() {
    this.barChartData = this.products.map(product => ({
      name: product.name,
      value: product.price,
    }));
  }

  // Close dialog
  closeDialog() {
    this.newProduct = { id: 0, name: '', price: 0 };
    this.displayDialog = false;
  }
}
